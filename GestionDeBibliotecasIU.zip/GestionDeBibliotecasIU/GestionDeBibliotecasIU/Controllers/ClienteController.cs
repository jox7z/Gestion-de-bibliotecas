﻿using GestionDeBibliotecasIU.Models;
using GestionDeBibliotecasIU.Servicios.Cliente;
using Microsoft.AspNetCore.Mvc;


namespace SegundoExamenPrograIU.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IsrvCliente gApiCliente;

        public ClienteController(IsrvCliente lApiCliente)
        {
            gApiCliente = lApiCliente;
        }

        public async Task<ActionResult> obtenerClientes()
        {
            List<mCliente> lObjRespuesta = new List<mCliente>();
            try
            {
                lObjRespuesta = await gApiCliente.obtenerClientes();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> agregaCliente()
        {
            return View();
        }

        public async Task<ActionResult> modificaCliente(int pIdCliente)
        {
            mCliente lObjRespuesta = new mCliente();
            try
            {
                lObjRespuesta = await gApiCliente.obtenerClienteXId(pIdCliente);
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> eliminaCliente(int pIdCliente)
        {
            mCliente lObjRespuesta = new mCliente();
            try
            {
                lObjRespuesta = await gApiCliente.obtenerClienteXId(pIdCliente);
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> detalleCliente(int pIdCliente)
        {
            mCliente lObjRespuesta = new mCliente();
            try
            {
                lObjRespuesta = await gApiCliente.obtenerClienteXId(pIdCliente);
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> insCliente(mCliente pCliente)
        {
            List<mCliente> lObjRespuesta = new List<mCliente>();
            try
            {
                if (await gApiCliente.agregaCliente(pCliente))
                {
                    // mensaje de éxito
                }
                else
                {
                    // mensaje de error
                }
                lObjRespuesta = await gApiCliente.obtenerClientes();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View("obtenerClientes", lObjRespuesta);
        }

        public async Task<ActionResult> modCliente(mCliente pCliente)
        {
            List<mCliente> lObjRespuesta = new List<mCliente>();
            try
            {
                if (await gApiCliente.modificaCliente(pCliente))
                {
                    // mensaje de éxito
                }
                else
                {
                    // mensaje de error
                }
                lObjRespuesta = await gApiCliente.obtenerClientes();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View("obtenerClientes", lObjRespuesta);
        }

        public async Task<ActionResult> delCliente(mCliente pCliente)
        {
            List<mCliente> lObjRespuesta = new List<mCliente>();
            try
            {
                if (await gApiCliente.eliminaCliente(pCliente.TnIdCliente))
                {
                    // mensaje de éxito
                }
                else
                {
                    // mensaje de error
                }
                lObjRespuesta = await gApiCliente.obtenerClientes();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View("obtenerClientes", lObjRespuesta);
        }
    }
}

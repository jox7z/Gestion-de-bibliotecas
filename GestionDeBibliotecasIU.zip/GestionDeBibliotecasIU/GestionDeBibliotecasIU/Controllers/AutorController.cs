﻿using GestionDeBibliotecasIU.Models;
using GestionDeBibliotecasIU.Servicios.Autor;
using Microsoft.AspNetCore.Mvc;


namespace SegundoExamenPrograIU.Controllers
{
    public class AutorController : Controller
    {
        private readonly IsrvAutor gApiAutor;

        public AutorController(IsrvAutor lApiAutor)
        {
            gApiAutor = lApiAutor;
        }

        public async Task<ActionResult> obtenerAutores()
        {
            List<mAutor> lObjRespuesta = new List<mAutor>();
            try
            {
                lObjRespuesta = await gApiAutor.obtenerAutores();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> agregaAutor()
        {
            return View();
        }

        public async Task<ActionResult> modificaAutor(int pIdAutor)
        {
            mAutor lObjRespuesta = new mAutor();
            try
            {
                lObjRespuesta = await gApiAutor.obtenerAutoresXId(pIdAutor);
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> eliminaAutor(int pIdAutor)
        {
            mAutor lObjRespuesta = new mAutor();
            try
            {
                lObjRespuesta = await gApiAutor.obtenerAutoresXId(pIdAutor);
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        public async Task<ActionResult> detalleAutor(int pIdAutor)
        {
            mAutor lObjRespuesta = new mAutor();
            try
            {
                lObjRespuesta = await gApiAutor.obtenerAutoresXId(pIdAutor);
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View(lObjRespuesta);
        }

        /***********************ACCIONES DE INS-MOD-DEL ****************************************/

        public async Task<ActionResult> insAutor(mAutor pAutor)
        {
            List<mAutor> lObjRespuesta = new List<mAutor>();
            try
            {
                if (await gApiAutor.agregaAutor(pAutor))
                {
                    // mensaje de éxito
                }
                else
                {
                    // mensaje de error
                }
                lObjRespuesta = await gApiAutor.obtenerAutores();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View("obtenerAutores", lObjRespuesta);
        }

        public async Task<ActionResult> modAutor(mAutor pAutor)
        {
            List<mAutor> lObjRespuesta = new List<mAutor>();
            try
            {
                if (await gApiAutor.modificaAutor(pAutor))
                {
                    // mensaje de éxito
                }
                else
                {
                    // mensaje de error
                }
                lObjRespuesta = await gApiAutor.obtenerAutores();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View("obtenerAutores", lObjRespuesta);
        }

        public async Task<ActionResult> delAutor(mAutor pAutor)
        {
            List<mAutor> lObjRespuesta = new List<mAutor>();
            try
            {
                if (await gApiAutor.eliminaAutor(pAutor.TnIdAutor))
                {
                    // mensaje de éxito
                }
                else
                {
                    // mensaje de error
                }
                lObjRespuesta = await gApiAutor.obtenerAutores();
            }
            catch (Exception lEx)
            {
                throw lEx;
            }
            return View("obtenerAutores", lObjRespuesta);
        }
    }
}

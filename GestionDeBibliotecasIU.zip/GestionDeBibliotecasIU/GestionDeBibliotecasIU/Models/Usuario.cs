﻿namespace GestionDeBibliotecasIU.Models
{
    public class Usuario
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
    }
}

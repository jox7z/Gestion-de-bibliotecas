﻿namespace GestionDeBibliotecasIU.Models
{
    public class mPrestamo
    {
        public int TnIdPrestamo { get; set; }

        public int? TnIdLibro { get; set; }

        public int? TnIdCliente { get; set; }

        public DateTime TfFecPrestamo { get; set; }

        public DateTime TfFecDevolucion { get; set; }

    }
}

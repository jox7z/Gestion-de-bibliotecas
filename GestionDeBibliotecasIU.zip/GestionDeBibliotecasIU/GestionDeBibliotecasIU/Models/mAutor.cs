﻿namespace GestionDeBibliotecasIU.Models
{
    public class mAutor
    {
        public int TnIdAutor { get; set; }

        public string TcNombre { get; set; } = null!;

        public string TcNacionalidad { get; set; } = null!;
    }
}

﻿namespace GestionDeBibliotecasIU.Models
{
    public class ResultadoToken
    {
        public string token { get; set; }
    }
}

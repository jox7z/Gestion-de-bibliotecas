﻿namespace GestionDeBibliotecasIU.Models
{
    public class mLibro
    {
        public int TnIdLibro { get; set; }

        public int? TnIdAutor { get; set; }

        public string TcTitulo { get; set; } = null!;

        public string TcEditorial { get; set; } = null!;

        public string TcCategoria { get; set; } = null!;
    }
}

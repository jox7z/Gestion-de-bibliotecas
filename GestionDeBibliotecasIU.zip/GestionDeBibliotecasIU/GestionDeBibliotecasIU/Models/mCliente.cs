﻿namespace GestionDeBibliotecasIU.Models
{
    public class mCliente
    {
        public int TnIdCliente { get; set; }

        public string TcNombre { get; set; } = null!;

        public string TcAp1 { get; set; } = null!;

        public string? TcAp2 { get; set; }

        public string? TcNumTelefono { get; set; }

        public string? TcCorreoElectronico { get; set; }

    }
}

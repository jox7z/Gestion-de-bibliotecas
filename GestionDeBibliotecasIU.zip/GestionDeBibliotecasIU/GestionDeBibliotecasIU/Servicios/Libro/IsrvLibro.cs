﻿using GestionDeBibliotecasIU.Models;

namespace GestionDeBibliotecasIU.Servicios.Libro
{
    public interface IsrvLibro
    {
            Task<List<mLibro>> obtenerLibros();
            Task<mLibro> obtenerLibroXId(int pIdLibro);
            Task<bool> agregaLibro(mLibro pLibro);
            Task<bool> modificaLibro(mLibro pLibro);
            Task<bool> eliminaLibro(int pIdLibro);
            Task<string> Autenticar(Usuario pLogin);   
    }
}

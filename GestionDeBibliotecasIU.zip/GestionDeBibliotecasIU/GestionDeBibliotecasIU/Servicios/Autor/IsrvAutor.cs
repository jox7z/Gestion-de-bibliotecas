﻿using GestionDeBibliotecasIU.Models;

namespace GestionDeBibliotecasIU.Servicios.Autor
{
    public interface IsrvAutor
    {
        Task<List<mAutor>> obtenerAutores();
        Task<mAutor> obtenerAutoresXId(int pIdAutor);
        Task<bool> agregaAutor(mAutor pAutor);
        Task<bool> modificaAutor(mAutor pAutor);
        Task<bool> eliminaAutor(int pIdAutor);
        Task<string> Autenticar(Usuario pLogin);
    }
}

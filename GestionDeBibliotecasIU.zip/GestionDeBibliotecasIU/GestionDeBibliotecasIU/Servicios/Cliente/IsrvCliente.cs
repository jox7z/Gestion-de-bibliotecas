﻿using GestionDeBibliotecasIU.Models;

namespace GestionDeBibliotecasIU.Servicios.Cliente
{
    public interface IsrvCliente
    {
        Task<List<mCliente>> obtenerClientes();
        Task<mCliente> obtenerClienteXId(int pIdCliente);
        Task<bool> agregaCliente(mCliente pCliente);
        Task<bool> modificaCliente(mCliente pCliente);
        Task<bool> eliminaCliente(int pIdCliente);
        Task<string> Autenticar(Usuario pLogin);
    }
}
﻿using GestionDeBibliotecasIU.Models;

namespace GestionDeBibliotecasIU.Servicios.Prestamo
{
    public interface IsrvPrestamo
    {
        Task<List<mPrestamo>> obtenerPrestamos();
        Task<mPrestamo> obtenerPrestamoXId(int pIdPrestamo);
        Task<bool> agregaPrestamo(mPrestamo pPrestamo);
        Task<bool> modificaPrestamo(mPrestamo pPrestamo);
        Task<bool> eliminaPrestamo(int pIdPrestamo);
        Task<string> Autenticar(Usuario pLogin);
    }
}

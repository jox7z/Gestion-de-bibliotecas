﻿namespace ApiGestionBiblioteca_Progra06.Modelos
{
    public class Usuario
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
    }
}
